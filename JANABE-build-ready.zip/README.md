# JANABE

Android network and security toolkit designed for normal, no-root operation.

## Current integrated features
- Android/Kotlin project
- Network information: transport, interface, local IPv4, gateway, DNS
- Local /24 discovery
- Reachability and common TCP service checks
- Basic device-type classification from observable network signals
- Device history with first-seen / last-seen
- Reports screen
- English UI with Arabic explanations
- No authentication bypass and no device-content inspection

## Android limitations
A normal Android application cannot freely obtain every detail about other devices. In particular, access to other devices' MAC addresses can be restricted by Android and by the network. JANABE must report unavailable fields as unavailable rather than inventing them.

## Build
This project is prepared for Android Gradle builds. A complete APK still requires an Android SDK/Gradle build environment.
