# JANABE — build from phone

1. Create a GitHub account and a new empty repository.
2. Upload/extract this project into the repository.
3. Open the repository's **Actions** tab.
4. Select **Build JANABE APK** and choose **Run workflow**.
5. When the run finishes successfully, open the run and download the **JANABE-debug-apk** artifact.
6. Extract the artifact and install `app-debug.apk` on Android.

This workflow builds the debug APK only. JANABE is designed for authorized/local network diagnostics.
