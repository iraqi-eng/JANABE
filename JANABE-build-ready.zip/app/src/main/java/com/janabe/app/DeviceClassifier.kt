package com.janabe.app

object DeviceClassifier {
    fun classify(ports: List<Int>, hostname: String): String {
        val h = hostname.lowercase()
        return when {
            554 in ports -> "IP Camera / RTSP device"
            445 in ports -> "Windows / SMB device"
            22 in ports && ("router" in h || "gateway" in h) -> "Router / Network device"
            80 in ports || 443 in ports -> "Web-enabled network device"
            22 in ports -> "Linux / Unix-like device"
            else -> "Unknown network device"
        }
    }
}
