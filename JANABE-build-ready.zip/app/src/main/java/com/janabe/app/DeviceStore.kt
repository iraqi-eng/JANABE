package com.janabe.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object DeviceStore {
    private const val PREFS = "janabe_devices"
    private const val KEY = "devices"

    fun load(context: Context): MutableList<DiscoveredDevice> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<DiscoveredDevice>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list += DiscoveredDevice(
                o.getString("ip"),
                o.optString("hostname", "Unknown"),
                o.optString("vendor", "Unknown"),
                o.optString("type", "Unknown"),
                jsonToPorts(o.optJSONArray("ports")),
                o.optLong("firstSeen"),
                o.optLong("lastSeen"),
                o.optBoolean("reachable")
            )
        }
        return list
    }

    fun upsert(context: Context, device: DiscoveredDevice) {
        val list = load(context)
        val index = list.indexOfFirst { it.ip == device.ip }
        if (index >= 0) {
            val old = list[index]
            list[index] = device.copy(firstSeen = old.firstSeen)
        } else {
            list += device
        }
        save(context, list)
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, "[]").apply()
    }

    private fun save(context: Context, list: List<DiscoveredDevice>) {
        val arr = JSONArray()
        list.forEach {
            val o = JSONObject()
            o.put("ip", it.ip)
            o.put("hostname", it.hostname)
            o.put("vendor", it.vendor)
            o.put("type", it.type)
            o.put("firstSeen", it.firstSeen)
            o.put("lastSeen", it.lastSeen)
            o.put("reachable", it.reachable)
            val ports = JSONArray()
            it.openPorts.forEach(ports::put)
            o.put("ports", ports)
            arr.put(o)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, arr.toString()).apply()
    }

    private fun jsonToPorts(arr: JSONArray?): List<Int> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.getInt(it) }
    }
}
