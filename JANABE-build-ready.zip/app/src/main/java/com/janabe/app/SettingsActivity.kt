package com.janabe.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        val title = TextView(this).apply {
            text = "Settings\nالإعدادات"
            textSize = 25f
        }
        val lang = TextView(this).apply {
            text = "Language: English + Arabic explanations\nاللغة: الإنجليزية + شرح عربي"
            textSize = 16f
            setPadding(0, 20, 0, 20)
        }
        val privacy = TextView(this).apply {
            text = "No-root design: JANABE uses Android public networking APIs. " +
                "Some device details, especially other devices' MAC addresses, may be restricted by Android.\n\n" +
                "تصميم بدون Root: يستخدم JANABE واجهات أندرويد الرسمية. " +
                "بعض التفاصيل، خصوصًا MAC للأجهزة الأخرى، قد يمنع أندرويد التطبيق العادي من الوصول إليها."
            textSize = 14f
        }
        root.addView(title); root.addView(lang); root.addView(privacy)
        setContentView(root)
    }
}
