package com.janabe.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Date

class ReportsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        val title = TextView(this).apply {
            text = "Reports\nالتقارير"
            textSize = 25f
        }
        val output = TextView(this).apply { textSize = 14f; setPadding(0, 18, 0, 0) }
        root.addView(title); root.addView(output)
        setContentView(root)

        val n = NetworkInspector.getNetworkInfo(this)
        val devices = DeviceStore.load(this)
        output.text = buildString {
            append("JANABE Network Report\n")
            append("Generated: ${Date()}\n\n")
            if (n != null) {
                append("Transport: ${n.transport}\n")
                append("Local IP: ${n.localIp}/${n.prefixLength}\n")
                append("Gateway: ${n.gateway}\n\n")
            }
            append("Known devices: ${devices.size}\n\n")
            devices.forEachIndexed { i, d ->
                append("${i + 1}. ${d.ip} | ${d.type} | ${d.hostname}\n")
                append("   Ports: ${d.openPorts.joinToString().ifBlank { "None" }}\n")
            }
        }
    }
}
