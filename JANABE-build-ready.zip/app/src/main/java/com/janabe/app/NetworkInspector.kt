package com.janabe.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import java.net.Inet4Address

data class NetworkInfo(
    val interfaceName: String,
    val localIp: String,
    val prefixLength: Int,
    val gateway: String,
    val dnsServers: List<String>,
    val transport: String
)

object NetworkInspector {
    fun getNetworkInfo(context: Context): NetworkInfo? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(network) ?: return null
        val lp: LinkProperties = cm.getLinkProperties(network) ?: return null

        val address = lp.linkAddresses.firstOrNull {
            it.address is Inet4Address && !it.address.isLoopbackAddress
        }
        val ip = address?.address?.hostAddress ?: return null
        val prefix = address?.prefixLength ?: 24

        val gateway = lp.routes.firstOrNull {
            it.gateway is Inet4Address && it.destination.prefixLength == 0
        }?.gateway?.hostAddress ?: "Unavailable"

        val transport = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other"
        }

        return NetworkInfo(
            interfaceName = lp.interfaceName ?: "Unknown",
            localIp = ip,
            prefixLength = prefix,
            gateway = gateway,
            dnsServers = lp.dnsServers.mapNotNull { it.hostAddress },
            transport = transport
        )
    }
}
