package com.janabe.app

data class DiscoveredDevice(
    val ip: String,
    val hostname: String,
    val vendor: String,
    val type: String,
    val openPorts: List<Int>,
    val firstSeen: Long,
    val lastSeen: Long,
    val reachable: Boolean
)
