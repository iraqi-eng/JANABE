package com.janabe.app

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
        }

        val title = TextView(this).apply {
            text = "JANABE"
            textSize = 32f
        }
        val subtitle = TextView(this).apply {
            text = "Network & Security Toolkit\nأدوات الشبكة والأمان"
            textSize = 17f
            setPadding(0, 8, 0, 24)
        }

        fun button(text: String, action: () -> Unit) =
            MaterialButton(this).apply {
                this.text = text
                setOnClickListener { action() }
            }

        root.addView(title)
        root.addView(subtitle)
        root.addView(button("Network Discovery\nاكتشاف أجهزة الشبكة") {
            startActivity(Intent(this, DiscoveryActivity::class.java))
        })
        root.addView(button("Device History\nسجل الأجهزة") {
            startActivity(Intent(this, HistoryActivity::class.java))
        })
        root.addView(button("Reports\nالتقارير") {
            startActivity(Intent(this, ReportsActivity::class.java))
        })
        root.addView(button("Settings\nالإعدادات") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })

        setContentView(root)
    }
}
