package com.janabe.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        val title = TextView(this).apply {
            text = "Device History\nسجل الأجهزة"
            textSize = 25f
        }
        val output = TextView(this).apply { textSize = 14f; setPadding(0, 18, 0, 0) }
        val clear = com.google.android.material.button.MaterialButton(this).apply {
            text = "Clear History\nمسح السجل"
            setOnClickListener {
                DeviceStore.clear(this@HistoryActivity)
                output.text = "History cleared.\nتم مسح السجل."
            }
        }
        root.addView(title); root.addView(clear); root.addView(output)
        setContentView(root)

        val devices = DeviceStore.load(this)
        output.text = if (devices.isEmpty()) {
            "No saved devices.\nلا توجد أجهزة محفوظة."
        } else {
            devices.joinToString("\n\n") {
                "${it.ip}\nType: ${it.type}\nHostname: ${it.hostname}\n" +
                "Ports: ${it.openPorts.joinToString().ifBlank { "None" }}\n" +
                "First seen: ${java.util.Date(it.firstSeen)}\nLast seen: ${java.util.Date(it.lastSeen)}"
            }
        }
    }
}
