package com.janabe.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

class DiscoveryActivity : AppCompatActivity() {
    private lateinit var result: TextView
    private lateinit var scanButton: MaterialButton
    private val executor = Executors.newFixedThreadPool(16)
    private val commonPorts = listOf(22, 53, 80, 443, 445, 554, 8080, 8443)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        val title = TextView(this).apply {
            text = "Network Discovery\nاكتشاف أجهزة الشبكة"
            textSize = 25f
        }
        val note = TextView(this).apply {
            text = "Local network discovery. No root required.\nاكتشاف الشبكة المحلية بدون Root."
            textSize = 14f
            setPadding(0, 10, 0, 16)
        }
        scanButton = MaterialButton(this).apply {
            text = "Start Scan\nبدء الفحص"
            setOnClickListener { startScan() }
        }
        result = TextView(this).apply {
            textSize = 14f
            setPadding(0, 18, 0, 0)
        }
        root.addView(title); root.addView(note); root.addView(scanButton); root.addView(result)
        setContentView(root)
        showNetwork()
    }

    private fun showNetwork() {
        val n = NetworkInspector.getNetworkInfo(this)
        result.text = if (n == null) {
            "No active IPv4 network.\nلا توجد شبكة IPv4 نشطة."
        } else {
            "Transport: ${n.transport}\nInterface: ${n.interfaceName}\n" +
            "Local IP: ${n.localIp}/${n.prefixLength}\nGateway: ${n.gateway}\n" +
            "DNS: ${n.dnsServers.joinToString().ifBlank { "Unavailable" }}"
        }
    }

    private fun startScan() {
        val n = NetworkInspector.getNetworkInfo(this)
        val ip = n?.localIp ?: run {
            result.text = "No IPv4 network found.\nلم يتم العثور على شبكة IPv4."
            return
        }
        val prefix = ip.substringBeforeLast(".")
        scanButton.isEnabled = false
        result.text = "Scanning $prefix.0/24...\nجاري الفحص..."

        executor.execute {
            var found = 0
            for (host in 1..254) {
                val target = "$prefix.$host"
                if (target == ip) continue
                val reachable = probe(target)
                if (reachable) {
                    found++
                    val ports = commonPorts.filter { isPortOpen(target, it) }
                    val now = System.currentTimeMillis()
                    val hostname = try {
                        InetAddress.getByName(target).canonicalHostName
                    } catch (_: Exception) { "Unknown" }
                    val type = DeviceClassifier.classify(ports, hostname)
                    DeviceStore.upsert(
                        this,
                        DiscoveredDevice(
                            target,
                            hostname,
                            "Unknown",
                            type,
                            ports,
                            now,
                            now,
                            true
                        )
                    )
                    runOnUiThread {
                        result.text = "Found: $found\n$target\nType: $type\n" +
                            "Ports: ${ports.ifEmpty { listOf() }.joinToString().ifBlank { "None detected" }}"
                    }
                }
            }
            runOnUiThread {
                result.text = "Scan complete.\nاكتمل الفحص.\n\nDevices found: $found\nالأجهزة المكتشفة: $found"
                scanButton.isEnabled = true
            }
        }
    }

    private fun probe(ip: String): Boolean {
        return listOf(80, 443, 22).any { isPortOpen(ip, it) }
    }

    private fun isPortOpen(ip: String, port: Int): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, port), 300)
                true
            }
        } catch (_: Exception) { false }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
